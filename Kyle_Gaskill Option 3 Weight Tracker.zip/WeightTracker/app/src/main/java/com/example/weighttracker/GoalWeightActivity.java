package com.example.weighttracker;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "goalWeight",
foreignKeys = @ForeignKey(entity = User.class,
parentColumns = "username",
childColumns = "username",
onDelete = ForeignKey.CASCADE),
indices = {@Index(value = {"username"}, unique = true)})
public class GoalWeightActivity {

    @PrimaryKey(autoGenerate = true)
    private int idNumber;

    private String username;
    private double goalWeight;

    //Default Constructor
    public GoalWeightActivity() {

    }

    public GoalWeightActivity(double goalWeight, String username){
        this.username = username;
        this.goalWeight = goalWeight;
    }

    //Getters
    public int getIdNumber() {
        return idNumber;

    }

    public String getUsername() {
        return username;

    }

    public double getGoalWeight() {
        return goalWeight;
    }

    //Setters
    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    public void setUsername(String username) {
        this.username = username;

    }

    public void setGoalWeight(double goalWeight) {
        this.goalWeight = goalWeight;
    }

}
