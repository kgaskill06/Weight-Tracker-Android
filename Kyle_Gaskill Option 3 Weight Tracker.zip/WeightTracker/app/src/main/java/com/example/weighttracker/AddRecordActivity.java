package com.example.weighttracker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddRecordActivity extends AppCompatActivity {

    // edit text variables for add_record xml
    private EditText mDate;
    private EditText mWeight;

    // button press variables for add_record xml
    private Button mSave;
    private Button mCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_record);

        mWeight = (EditText) this.findViewById(R.id.add_record_edittext);
        mDate   = (EditText) this.findViewById(R.id.editTextDate);
    }

    public void saveButtonClick(View view) {
        /*
        TODO:
         */
    }

    public void cancelButtonClick(View view) {
        /*
        TODO:
         */

    }

}
