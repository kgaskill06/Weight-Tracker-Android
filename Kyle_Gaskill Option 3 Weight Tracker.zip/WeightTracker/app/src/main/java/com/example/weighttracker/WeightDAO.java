package com.example.weighttracker;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.Date;
import java.util.List;

@Dao
public interface WeightDAO {

    // gets all daily weights and orders by date
    @Query("SELECT * from dailyWeights ORDER BY date")
    List<WeightHistory> getDailyWeights();

    /*
    gets all daily weights by username, orders by date in ascending
     */
    @Query("SELECT * from dailyWeights WHERE username = :input ORDER BY date ASC")
    List<WeightHistory> getWeightsByDate(String input);

    // gets weights by username and date
    @Query("SELECT * from dailyWeights WHERE username = :username AND date = :date")
    public WeightHistory getWeightsAndDate(String username, Date date);

    //Deletes weight record
    @Query("DELETE from dailyWeights WHERE username = :username AND date = :date")
    void deleteWeight(String username, Date date);

    //insert new daily weight
    @Insert(onConflict = OnConflictStrategy.ABORT)
    public void insertWeight(WeightHistory weight);

    //changes weight record
    @Update
    void updateWeight(WeightHistory weight);

    // Deletes weight record
    @Delete
    void deleteWeight(WeightHistory weight);



}
