package com.example.weighttracker;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface GoalWeightDAO {

    /*
    Gets all goal weights from all usernames and orders by id number. outputs all weights into a list.
     */
    @Query("SELECT * from goalWeight WHERE username = :username ORDER BY idNumber")
    List<GoalWeightActivity> getGoalWeight(String username);

    /*
    Gets current user goal weight
     */
    @Query("SELECT * from goalWeight WHERE username = :username")
    GoalWeightActivity getUserGoalWeight(String username);

    /*
    Updates goal weight for current user
     */
    @Query("UPDATE goalWeight SET goalWeight = :updatedGoal WHERE username = :username")
    void updateGoalWeight(double updatedGoal, String username);


    //inserts new goal if one is not set.
    @Insert(onConflict = OnConflictStrategy.ABORT)
    void insertGoalWeight(GoalWeightActivity goalWeight);



}
