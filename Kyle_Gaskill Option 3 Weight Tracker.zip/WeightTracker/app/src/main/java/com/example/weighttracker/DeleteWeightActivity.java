package com.example.weighttracker;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DeleteWeightActivity extends AppCompatActivity {

    private User mUser;
    private WeightDatabaseActivity mWeightDb;
    TextView mTargetGoalWeight;
    WeightEntity mNewWeightEntry;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        //singleton implement
        mWeightDb = WeightDatabaseActivity.getInstance(getApplicationContext());

    }
}
