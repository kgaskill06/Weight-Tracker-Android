package com.example.weighttracker;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import com.example.weighttracker.User;
import java.util.List;

@Dao
public interface UserDAO {

    // queries for all from users and orders by username
    @Query("SELECT * FROM users ORDER BY username")
    List<User> getUsers();

    // User class reference as list to add remove and store users

    @Insert(onConflict = OnConflictStrategy.ABORT)
    void insertUser(User user);

    @Update
    void updateUser(User user);

    @Delete
    void deleteUser(User user);





}
